#include <unistd.h>
#include <stdio.h>
main()
{
	printf("%d\n",getpid());
	while(1);
}
