/*
create or replace function getname(eno number)
return varchar2 is name varchar(20);
begin
  select ename into name from emp where empno=eno;
  return name; 
end;

*/

/*
���ô洢����

select getname(7900) from dual;
*/


/*
create or replace procedure addrec(dn number,na varchar2,lo varchar2)
is
begin
  insert into dept(deptno,dname,loc) values(dn,na,lo);
end;

*/

/*
���ô洢����
call addrec(90,'Hello','world');
*/
