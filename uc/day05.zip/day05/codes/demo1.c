#include <stdio.h>
main()
{
	/*��ע��*/	
	int sum=0;
	int i;
	for(i=0;i<100;i++){
		sum+=i;
	}
	printf("%d\n",sum);
}

