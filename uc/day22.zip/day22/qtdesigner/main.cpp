#include <QApplication>
#include "jfqdlg.h"
int main(int args,char **argv){
	QApplication app(args,argv);
	QJfqDlg  dlg;
	return app.exec();
}
