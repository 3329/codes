/*
线程的属性
API：
int pthread_create(pthread_t * thread,
						 const pthread_attr_t * attr,
						 void *(*start_routine)(void*),
						 void * arg);
pthread_attr_t 实际是一个联合变体：用来指明线程创建的属性。
	typedef union
	{
	  char __size[__SIZEOF_PTHREAD_ATTR_T];
	  long int __align;
	} pthread_attr_t;
其中__SIZEOF_PTHREAD_ATTR_T宏定义如下：
#define __SIZEOF_PTHREAD_ATTR_T 36


在线程属性操作中提供了一系列函数进行操作。
	1._detachstate  表示新线程是否与进程中的其他线程脱离同步。
		Detach state.
		enum
		{
			PTHREAD_CREATE_JOINABLE,
				#define PTHREAD_CREATE_JOINABLE PTHREAD_CREATE_JOINABLE
			PTHREAD_CREATE_DETACHED  不能使用pthread_join来同步。
				#define PTHREAD_CREATE_DETACHED PTHREAD_CREATE_DETACHED
		};
		该属性可以使用pthread_detach来设置。一旦设置后不能再恢复到joinable状态
		int pthread_detach(pthread_t thread);

	2._schedpolicy
		表示新线程的调度策略
		Scheduling algorithms：
		#define  SCHED_OTHER     0  正常非实时
		#define  SCHED_FIFO      1  实时先进先出
		#define  SCHED_RR        2  实时轮转
		#define  SCHED_BATCH     3  对GNU使用
		该属性可以使用pthread_setschedparam来设置。
		其中sched_param结构体定义为
		struct sched_param
  		{
    		int __sched_priority;
  		};
		其中优先级只对SCHED_FIFO 与SCHED_RR实时调度策略有效。
		int pthread_getschedparam(	pthread_t thread,
											int *restrict policy,
              							struct sched_param *restrict param);
       int pthread_setschedparam(pthread_t thread,
											int policy,
              							const struct sched_param *param);
	3._schedparam
		就是上面的策略中指定的优先级。结构体定义如上。
	4._inheritsched
		表示是否显式指定调度策略与参数。
		可能的值如下：
		enum
		{
  			PTHREAD_INHERIT_SCHED,继承调用者线程的值。
				#define PTHREAD_INHERIT_SCHED   PTHREAD_INHERIT_SCHED
			PTHREAD_EXPLICIT_SCHED显式指定调度策略与参数。
				#define PTHREAD_EXPLICIT_SCHED  PTHREAD_EXPLICIT_SCHED
		};
	5._scope
		表示线程的竞争范围：
		可能值有：
		enum
		{
  			PTHREAD_SCOPE_SYSTEM,系统中所有线程竞争CPU
				#define PTHREAD_SCOPE_SYSTEM    PTHREAD_SCOPE_SYSTEM
  			PTHREAD_SCOPE_PROCESS 进程中竞争CPU，目前Linux没有实现。
				#define PTHREAD_SCOPE_PROCESS   PTHREAD_SCOPE_PROCESS
		};
	还有很多其他属性，但在创建线程的时候基本无效。
int pthread_attr_init(pthread_attr_t *);
int pthread_attr_destroy(pthread_attr_t *);

int pthread_attr_getdetachstate(const pthread_attr_t *, int *);
int pthread_attr_getguardsize(const pthread_attr_t *restrict,size_t *restrict);
int pthread_attr_getinheritsched(const pthread_attr_t *restrict,int *restrict);
int pthread_attr_getschedparam(const pthread_attr_t *restrict,struct sched_param *restrict);
int pthread_attr_getschedpolicy(const pthread_attr_t *restrict,int *restrict);
int pthread_attr_getscope(const pthread_attr_t *restrict,int *restrict);
int pthread_attr_getstack(const pthread_attr_t *restrict,void **restrict, size_t *restrict);
int pthread_attr_getstackaddr(const pthread_attr_t *restrict,void **restrict);
int pthread_attr_getstacksize(const pthread_attr_t *restrict,size_t *restrict);

int pthread_attr_setdetachstate(pthread_attr_t *, int);
int pthread_attr_setguardsize(pthread_attr_t *, size_t);
int pthread_attr_setinheritsched(pthread_attr_t *, int);
int pthread_attr_setschedparam(pthread_attr_t *restrict,const struct sched_param *restrict);
int pthread_attr_setschedpolicy(pthread_attr_t *, int);
int pthread_attr_setscope(pthread_attr_t *, int);
int pthread_attr_setstack(pthread_attr_t *, void *, size_t);
int pthread_attr_setstackaddr(pthread_attr_t *, void *);
int pthread_attr_setstacksize(pthread_attr_t *, size_t);
属性设置相关函数



*/

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <sys/types.h>
void* th(void *data);
int main()
{
	pthread_t  th1;
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);
	char d[]="Hello我是参数！";
	int re=pthread_create(&th1,&attr,(void*)th,&d);
	if(re)
	{
		printf("创建线程失败\n");
		exit(1);
	}
	//pthread_detach(th1);
	sleep(5);
	char *rd;
	pthread_join(th1,(void**)&rd);
	printf("线程返回的数据%s\n",rd);
	printf("主程序退出\n");
	/*主进程结束，子线程也结束并自动释放资源。*/
	return 0;
}
void* th(void *data)
{
	int i=0;
	for(;;i++)
	{
		printf("\tThread -1:%s\n",data);
		system("echo `date`>>a.txt");
		sleep(1);
	}
	return data;
}

