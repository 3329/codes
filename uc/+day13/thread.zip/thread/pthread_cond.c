/*
条件量
int pthread_cond_init(pthread_cond_t * cond,const pthread_condattr_t * attr);
int pthread_cond_destroy(pthread_cond_t *cond);
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
=================================================================
int pthread_cond_timedwait(pthread_cond_t *,pthread_mutex_t *,const struct timespec *);
在指定时间内阻塞线程
int pthread_cond_wait(pthread_cond_t *,pthread_mutex_t *);
阻塞线程
=================================================================
int pthread_cond_signal(pthread_cond_t *);
解除线程阻塞
int pthread_cond_broadcast(pthread_cond_t *);
解除所有线程阻塞
*/

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
void* th1(void *data);
void* th2(void *data);
pthread_mutex_t  mutex;
pthread_cond_t  cond;
int main()
{
	pthread_t  t1,t2;
	/*初始化mutex*/
	pthread_mutex_init(&mutex,NULL);
	pthread_cond_init(&cond,NULL);

	pthread_create(&t1,NULL,(void*)th1,NULL);
	pthread_create(&t2,NULL,(void*)th2,NULL);
	//定时解除线程阻塞	
	while(1)
	{
		//pthread_cond_signal(&cond);
		pthread_cond_broadcast(&cond);
		sleep(3);
	}	
	pthread_join(t1,NULL);
	pthread_join(t2,NULL);
	pthread_cond_destroy(&cond);
	pthread_mutex_destroy(&mutex);
	printf("主程序退出\n");
	sleep(4);
	return 0;
}
void* th1(void *data)
{
	while(1)
	{
		pthread_mutex_lock(&mutex);
		pthread_cond_wait(&cond,&mutex);
		printf("\tThread-1\n");	
		//sleep(1);	
		pthread_mutex_unlock(&mutex);
	}
	return NULL;
}

void* th2(void *data)
{
	while(1)
	{
		pthread_mutex_lock(&mutex);				
		pthread_cond_wait(&cond,&mutex);
		printf("\tThread-2\n");
		//sleep(1);
		pthread_mutex_unlock(&mutex);
	}
	return NULL;
}
