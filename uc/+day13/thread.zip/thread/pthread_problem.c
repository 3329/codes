/*
多线程造成的数据问题。 
问题：为什么出现这种情况？	
*/

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
void* th1(void *data);
void* th2(void *data);
int a,b;

void play()
{
	a++;
	b++;
	if(a!=b)
	{
		printf("%d!=%d\n",a,b);
		a=b=0;
	}
}
int main()
{
	a=b=0;
	pthread_t  t1,t2;
	pthread_create(&t1,NULL,(void*)th1,NULL);
	pthread_create(&t2,NULL,(void*)th2,NULL);
	
	pthread_join(t1,NULL);
	pthread_join(t2,NULL);

	printf("主程序退出\n");
	sleep(4);
	return 0;
}
void* th1(void *data)
{
	while(1)
	{
		play();
	}
	return NULL;
}

void* th2(void *data)
{
	while(1)
	{
		play();
	}
	return NULL;
}
