/*
线程的创建 
进程前的回调函数设置	不推荐使用咯！
*/

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
void init()
{
	printf("init\n");
}
void parent_init()
{
	printf("parent_init\n");
}
void child_init()
{
	printf("child_init\n");
}

int main()
{
	pthread_atfork(init,parent_init,child_init);
	if(fork()==0)
	{
		printf("子程序\n");
	}
	else
	{	
		printf("主程序\n");
	}
	return 0;
}


