/*
线程的取消
API：
	int pthread_cancel(pthread_t thread);发送一个cancel信号

	void pthread_testcancel(void);测试退出点,就是测试cancel信号

	int pthread_setcancelstate(int state, int *oldstate);设置本线程对信号的反应
状态有两种：
   PTHREAD_CANCEL_ENABLE  默认，收到cancel信号马上设置退出状态。
   PTHREAD_CANCEL_DISABLE 收到cancel信号继续运行。
	int pthread_setcanceltype(int type, int *oldtype);
类型有两种，只有在PTHREAD_CANCEL_ENABLE状态下有效
	PTHREAD_CANCEL_ASYNCHRONOUS  立即执行取消信号
   PTHREAD_CANCEL_DEFERRED		  运行到下一个取消点

*/

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <sys/types.h>

void* th(void *data);
int main()
{
	pthread_t  th1;
	char d[]="Hello我是参数！";
	int re=pthread_create(&th1,NULL,(void*)th,&d);
	if(re)
	{
		printf("创建线程失败\n");
		exit(1);
	}
	sleep(5);
	pthread_cancel(th1);
	//pthread_join(th1,(void**)NULL);
	printf("主程序退出\n");
	/*主进程结束，子线程也结束并自动释放资源。*/
	return 0;
}
void* th(void *data)
{
	int i=0;
	for(;;i++)
	{

		printf("\tThread -1:%d\n",i);
		sleep(1);
		//pthread_testcancel();

	}
	return data;
}

