/*
互斥信号

int pthread_mutex_init(pthread_mutex_t *mutex,const pthread_mutexattr_t *attr);
创建互斥信号mutex
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
全局静态的mutex创建方式
int pthread_mutex_destroy(pthread_mutex_t *mutex);
删除mutex
int pthread_mutex_lock(pthread_mutex_t *mutex);
互斥锁定
int pthread_mutex_trylock(pthread_mutex_t *mutex);
互斥锁定
int pthread_mutex_unlock(pthread_mutex_t *mutex);
互斥解锁
===============================
互斥属性
int   pthread_mutexattr_init(pthread_mutexattr_t *);
int   pthread_mutexattr_destroy(pthread_mutexattr_t *);

int   pthread_mutexattr_getprioceiling(const pthread_mutexattr_t *, int *);
int   pthread_mutexattr_getprotocol(const pthread_mutexattr_t *,int *);
int   pthread_mutexattr_getpshared(const pthread_mutexattr_t *,int *restrict);
int   pthread_mutexattr_gettype(const pthread_mutexattr_t *,int *);

int   pthread_mutexattr_setprioceiling(pthread_mutexattr_t *, int);
设置mutex的优先级：最大优先级在如下范围内SCHED_FIFO
int   pthread_mutexattr_setprotocol(pthread_mutexattr_t *, int);
设置mutex的协议：
	PTHREAD_PRIO_NONE：互斥不受线程的优先级改变

	PTHREAD_PRIO_INHERIT：互斥受线程的优先级改变

   PTHREAD_PRIO_PROTECT：拥有多个互斥的线程，使用互斥的最高权限运行不考虑其他线程在互斥上的锁定

int   pthread_mutexattr_setpshared(pthread_mutexattr_t *, int);
设置线程的共享级别	
	PTHREAD_PROCESS_SHARED：共享
	PTHREAD_PROCESS_PRIVATE：同一进程创建的线程才能访问
int   pthread_mutexattr_settype(pthread_mutexattr_t *, int);
	PTHREAD_MUTEX_NORMAL 不检测死锁，如果锁定没有解锁的mutex会产生死锁。
	PTHREAD_MUTEX_ERRORCHECK  当试图锁定没有解锁的mutex就会发生错误。
	PTHREAD_MUTEX_RECURSIVE   对没有解锁的mutex进行锁定，可以锁定成功，而且不会发生死锁
	PTHREAD_MUTEX_DEFAULT  如果递归锁定，或者不是加锁线程解锁会发生未知情况，在Solaris与 NORMAL等价

*/

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
void* th1(void *data);
void* th2(void *data);
int a,b;
pthread_mutex_t  mutex;
void play()
{
	//注意锁加的位置
	pthread_mutex_lock(&mutex);
	a++;
	b++;
	pthread_mutex_unlock(&mutex);	
	if(a!=b)
	{
		printf("%d!=%d\n",a,b);
		a=b=0;
	}
	//pthread_mutex_unlock(&mutex);
}
int main()
{
	a=b=0;
	pthread_t  t1,t2;
	/*初始化mutex*/
	pthread_mutex_init(&mutex,NULL);

	pthread_create(&t1,NULL,(void*)th1,NULL);
	pthread_create(&t2,NULL,(void*)th2,NULL);
	
	pthread_join(t1,NULL);
	pthread_join(t2,NULL);
	pthread_mutex_destroy(&mutex);
	printf("主程序退出\n");
	sleep(4);
	return 0;
}
void* th1(void *data)
{
	while(1)
	{
		play();
	}
	return NULL;
}

void* th2(void *data)
{
	while(1)
	{
		play();
	}
	return NULL;
}
