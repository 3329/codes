/*
其他线程函数
pthread_t pthread_self(void);
获取线程ID
int pthread_once(pthread_once_t *, void (*)(void));
执行一次的线程
*/

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
void* th1(void *data);
void* th2(void *data);

int main()
{
	pthread_t  t1,t2;
	pthread_create(&t1,NULL,(void*)th1,NULL);
	pthread_create(&t2,NULL,(void*)th2,NULL);
	pthread_join(t1,NULL);
	pthread_join(t2,NULL);
	printf("主程序退出\n");
	sleep(4);
	return 0;
}
void* th1(void *data)
{
	while(1)
	{
		printf("\tThread-1：%d\n",pthread_self());	
		sleep(1);	

	}
	return NULL;
}

void* th2(void *data)
{
	while(1)
	{
		printf("\tThread-2：%d\n",pthread_self());
		sleep(1);
	}
	return NULL;
}
