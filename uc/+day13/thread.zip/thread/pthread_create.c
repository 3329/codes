/*
线程的创建 
API：
int pthread_create(pthread_t * thread,
						 const pthread_attr_t * attr,
						 void *(*start_routine)(void*), 
						 void * arg);
返回：
	成功返回0，失败返回错误号，错误号说明如下：
	EAGAIN 创建线程的系统资源不足，或者超过系统限制的最大线程数PTHREAD_THREADS_MAX
	EINVAL 创建线程的属性非法，就是第二个参数设置不正确。
	EPERM  调用者没有足够的权限。
参数说明：
	pthread_t * thread：线程ID
	pthread_attr_t * attr：线程属性，如果是NULL，则采用缺省属性。
	void *(*start_routine)(void*)线程执行代码
	void * arg传递给线程执行代码过程的参数
============================
int pthread_join(pthread_t thread, void **value_ptr);
返回：成功返回0，失败返回非0的错误号。错误号说明如下：
	EINVAL 指定的线程ID不是合法的ID，就是不可JOIN的线程。
	ESRCH  指定的线程ID不存在。
	EDEADLK指定的线程被死锁。
参数说明：
	thread：就是要JOIN的线程ID。
	value_ptr：就是线程函数的返回值。	
*/

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
void* th(void *data);
int main()
{
	pthread_t  th1;
	char d[]="Hello我是参数！";
	int re=pthread_create(&th1,NULL,(void*)th,&d);
	if(re)
	{
		printf("创建线程失败\n");
		exit(1);
	}
	char *rd;
	pthread_join(th1,(void**)&rd);
	printf("线程返回的数据%s\n",rd);
	printf("主程序退出\n");
	return 0;
}
void* th(void *data)
{
	int i=0;
	for(;i<10;i++)
	{
		printf("\tThread -1:%s\n",data);
		sleep(1);
	}
	return data;
}

