/*
线程的退出
API：
	void pthread_exit(void *value_ptr);

	void pthread_cleanup_pop(int execute);
	void pthread_cleanup_push(void (*routine)(void*), void *arg);


*/

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <sys/types.h>
void* th(void *data);
int main()
{
	pthread_t  th1;
	char d[]="Hello我是参数！";
	int re=pthread_create(&th1,NULL,(void*)th,&d);
	if(re)
	{
		printf("创建线程失败\n");
		exit(1);
	}
	char *rd;
	pthread_join(th1,(void**)&rd);
	printf("线程返回的数据%s\n",rd);
	printf("主程序退出\n");
	/*主进程结束，子线程也结束并自动释放资源。*/
	return 0;
}
void* th(void *data)
{	
	int i=0;
	for(;;i++)
	{		
		printf("\tThread -1:%d\n",i);
		if(i==5)
		{				
			pthread_exit("hello");
		}
		
	}
	return data;
}

