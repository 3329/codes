/*
线程私有数据
创建删除key
int pthread_key_create(pthread_key_t *key, void (*destructor)(void*));
	返回：成功返回0，失败返回错误号
	参数：pthread_key_t *key：返回的key
		  void (*destructor)(void*)：数据释放的回调函数，只有当数据非空的时候才被调用	
	
int pthread_key_delete(pthread_key_t key);
	略

存取key数据
void *pthread_getspecific(pthread_key_t key);
	有数据返回数据指针
	没有数据或者失败返回NULL
int pthread_setspecific(pthread_key_t key, const void *value);
	成功返回0
	失败返回错误号

	
*/

#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
void* th1(void *data);
void* th2(void *data);
void des(void*data)
{
	/*KEY ID*/
	printf("destructor:%d\n",*(int*)data);
}
pthread_key_t key;

int main()
{
	pthread_t  t1,t2;

	pthread_key_create(&key, des);	

	pthread_create(&t1,NULL,(void*)th1,NULL);
	pthread_create(&t2,NULL,(void*)th2,NULL);
	
	pthread_join(t1,NULL);
	pthread_join(t2,NULL);

	printf("主程序退出\n");
	sleep(4);
	return 0;
}
void* th1(void *data)
{
	int i=0;
	char d[]="hello";
	for(;i<10;i++)
	{
		pthread_setspecific(key,d);		
		printf("\tThread -1:%s\n",pthread_getspecific(key));
		sleep(1);
	}
	return NULL;
}

void* th2(void *data)
{
	int i=0;
	pthread_setspecific(key,"TSD");
	for(;i<10;i++)
	{
		printf("\tThread -2:%s\n",pthread_getspecific(key));
		sleep(1);
	}
	return NULL;
}
